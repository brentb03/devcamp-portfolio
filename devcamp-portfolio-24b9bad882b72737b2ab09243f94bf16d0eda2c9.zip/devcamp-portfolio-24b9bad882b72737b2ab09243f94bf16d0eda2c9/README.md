# Devcamp Portfolio Application

> This is a Ruby on Rails 5 application that allows users to create their own portfolios.

### Features

- Real time chat engine for comments
- Blog
- Portfolio
- Drag and drop interface

### Code Example

```ruby
def my_great_method
  puts "here it is"
end
```

```javascript
alert('Hi there');
```